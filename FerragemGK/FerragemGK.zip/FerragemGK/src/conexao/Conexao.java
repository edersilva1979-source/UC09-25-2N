
package conexao;

/**
 *
 * @author Eder Silva
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    private static final String URL =
            "jdbc:postgresql://localhost/FerragemGK";

    private static final String USUARIO = "postgres";

    private static final String SENHA = "root";

    public static Connection conectar() throws SQLException {

        return DriverManager.getConnection(
                URL,
                USUARIO,
                SENHA
        );
    }
}